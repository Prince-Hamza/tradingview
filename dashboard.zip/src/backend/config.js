export const firebaseConfig = {
    apiKey: "AIzaSyBhKtn4TK7LY4cG6zOZ8RPWBx12IDrxAhc",
    authDomain: "my-first-project-ce24e.firebaseapp.com",
    databaseURL: "https://my-first-project-ce24e.firebaseio.com",
    projectId: "my-first-project-ce24e",
    storageBucket: "my-first-project-ce24e.appspot.com",
    messagingSenderId: "627497957398",
    appId: "1:627497957398:web:8049cba44bd6c2ee49dd37"
  }