

export const pairsList = [
    'USDJPY',
    'BTCUSD',
    'ETHUSD',
    'EURUSD',
    'GBPUSD',
    'AAPL',
    'GBPJPY',
    'ES',
    'TSLA',
    'ETHUSD',
    'AUDUSD',
    'SOLUSD',
    'USCAD',
    'USOIL',
    'EURJPY',
    'BBY',
    'QQQ',
    'ADAUSD',
    'MATICUSD',
    'BNBUSD'
]