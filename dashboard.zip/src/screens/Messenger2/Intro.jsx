import React from 'react'

export default function Intro() {
  return (
    <div>Intro</div>
  )
}
